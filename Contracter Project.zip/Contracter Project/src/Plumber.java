public class Plumber extends Worker { 
	private double plumbingMaterials = 0;

	public Plumber(String firstName, String lastName, Address address, int idNumber, double hours, double rate) {
		super(firstName, lastName, address, idNumber, hours, rate);
	}

	public void setPlumbingCost(double amount) {
		plumbingMaterials = amount;
	}

	public String doWork() {
		return "Install plumbing";
	}

	@Override
	public String toString() { 
		return "Plumber: " + super.toString() + "\n" + doWork();
	}

	public double calculatePay() { 
		return super.calculatePay() + plumbingMaterials;
	}
}