public class Electrician extends Worker { 
	private double wiringCost = 0.0;

	public Electrician(String firstName, String lastName, Address address, int idNumber, double hours, double rate) {
		super(firstName, lastName, address, idNumber, hours, rate); 
	}

	public void setWiringCosts(double amount) {
		wiringCost = amount;
	}

	public String doWork() { 
		return "Install electrical components";
	}

	@Override
	public String toString() { 
		return "Electrician: " + super.toString() + "\n" + doWork();
	}

	public double calculatePay() { 
		return super.calculatePay() + wiringCost;
	}
}